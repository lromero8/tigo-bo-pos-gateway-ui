import { Component, OnInit, ViewEncapsulation, ViewChild, Injectable } from '@angular/core';

import { FormBuilder, FormGroup, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';

import { DatatableComponent } from '@swimlane/ngx-datatable';
import { ToastrService } from 'ngx-toastr';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { environment } from '../../../environments/environment';
import { NgbDatepickerI18n } from '@ng-bootstrap/ng-bootstrap';

import { I18n } from '../../../environments/i18n/i18n';
import { CustomDatepickerI18n } from '../../../environments/i18n/CustomDatepickerI18n';

import { CorelogService } from '../../services/corelog.service';

@Component({
  selector: 'app-corelog',
  templateUrl: './corelog.component.html',
  styleUrls: ['./corelog.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [I18n, { provide: NgbDatepickerI18n, useClass: CustomDatepickerI18n }]
})
export class CorelogComponent implements OnInit {

  public sortBy: string;
  public formSearch: FormGroup;
  public rows = [];
  public filterValue;
  public permissions: any;

  constructor(
    private logService: CorelogService, 
    private toastr: ToastrService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.formSearch = this.formBuilder.group({
      type: [''],
      nit: ['', Validators.maxLength(25)],
      no_doc: ['', Validators.maxLength(25)],
      since: [''],
      until: [''],
      endUser: [''],
      originReferenceId: ['']
    }
    );
    this._loadLogs();
  }

  private _loadLogs() {
    this.logService.getResource().subscribe(
      data => {
        if (data.headers[environment.HEADER_SERVICE_CODE] === environment.SUCCESS_CODE) {
          this.rows = data.parameters;
        } else {
          this.toastr.error(data.headers[environment.HEADER_SERVICE_DESCRIPTION]);
        }
      },
      error => {
        this.toastr.error(environment.SERVER_ERROR_MSG);
      },
      () => {
        this.rows = [...this.rows];
      }
    );
  }

  preventInput(event) {
    event.preventDefault();
  }

  search() {

  }

}
