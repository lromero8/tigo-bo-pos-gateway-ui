import { Component, OnInit, ViewEncapsulation, HostListener } from '@angular/core';
import { UserIdleService } from 'angular-user-idle';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-idle',
  templateUrl: './idle.component.html',
  styleUrls: ['./idle.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class IdleComponent implements OnInit {

  constructor(
    private userIdle: UserIdleService,
    private _route: ActivatedRoute,
		private _router: Router
  ){}
    
    ngOnInit() {

    //this.userIdle.startWatching();
    this.userIdle.onTimerStart().subscribe(count => console.log(count));
    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => 
      this.redirect()
    );
  }

  /**
   * 
   */
  stop() {
    this.userIdle.stopTimer();
  }

  /**
   * 
   */
  stopWatching() {
    this.userIdle.stopWatching();
  }

  /**
   * 
   */
  startWatching() {
    this.userIdle.startWatching();
  }

  /**
   * 
   */
  restart() {
    this.userIdle.resetTimer();
  }
  
  /**
   * 
   */
  redirect(){
		this._router.navigate(['/login']);
	}

  @HostListener('click', ['$event'])
  onClick(e) {
    console.log(e)
  }

  @HostListener('mouseover', ['$event']) onHover() {
    console.log("hover");
  }
}
